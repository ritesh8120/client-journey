<?php
include('config.php');
if (isset($_POST['cid'])) {
    $clientID = $_POST['cid'];
    $title = $_POST['title2'];
    $details = $_POST['notes'];
    $comment = $_POST['comment'];
    $date = date('Y-m-d');
    $target_dir = "https://www.localhost/uploads/uploads/";
    $postcontent = $target_dir . basename($_FILES["postcontent"]["name"]);
    move_uploaded_file($_FILES["postcontent"]["tmp_name"], $postcontent);

    $sql = "INSERT INTO `post_history`(`title`, `historyNotes`, `postcontent`, `comment`, `fld_date`, `user_id`) VALUES ('$title','$details','$postcontent','$comment','$date','$clientID')";

    if ($conn->query($sql) === TRUE) {

        $historyMember = $conn->query("SELECT * FROM `history` WHERE `client_id`='$clientID'");

        if ($historyMember->num_rows > 0) {
            $listView = "";

            $i = 1;

            while ($history = $historyMember->fetch_assoc()) { ?>

                <tr>

                    <td width="100"><?= $i ?></td>

                    <td width="200"><?php echo date("m/d/Y", strtotime($history['date'])) ?></td>

                    <td width="500"><?php echo nl2br($history['notes']) ?></td>

                    <td width="100"><a href="">Edit</a></td>

                    <td width="100"><a href="">Delet</a></td>

                </tr>

<?php

                $i++;
            }
        }

        $response['data'] = $listView;
    } else {

        $response['status'] = 0;

        $response['message'] = 'Error while adding notes.';

        $response['data'] = "";
    }
}

?>