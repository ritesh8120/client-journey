<?php
date_default_timezone_set("UTC");
$conn = new mysqli('localhost','root','','clientjourney');
?>